..\bin\lcc -o 8q.gb ..\lib\terminal.o ..\lib\stdio.o 8q.c
..\bin\lcc -o array.gb ..\lib\terminal.o ..\lib\stdio.o array.c
..\bin\lcc -o init.gb ..\lib\terminal.o ..\lib\stdio.o init.c
..\bin\lcc -o sort.gb ..\lib\terminal.o ..\lib\stdio.o sort.c
..\bin\lcc -o struct.gb ..\lib\terminal.o ..\lib\stdio.o struct.c
..\bin\lcc -o test.gb ..\lib\terminal.o ..\lib\drawing.o ..\lib\stdio.o test.c

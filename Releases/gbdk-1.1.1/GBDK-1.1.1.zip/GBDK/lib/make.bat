..\bin\lcc -c -o crt0.o crt0.s
..\bin\lcc -c -o terminal.o terminal.s
..\bin\lcc -c -o drawing.o drawing.s
..\bin\lcc -c -o stdio.o stdio.c

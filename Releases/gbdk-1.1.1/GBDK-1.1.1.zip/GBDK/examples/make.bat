..\bin\lcc -o space.gb space.s
..\bin\lcc -o sprite.gb sprite.c
..\bin\lcc -o rpn.gb ..\lib\terminal.o ..\lib\stdio.o rpn.c
..\bin\lcc -o sound.gb ..\lib\terminal.o ..\lib\stdio.o sound.c

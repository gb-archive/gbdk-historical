/*
 * gb.c:
 */

/*
 * Flags: name=string,first=hexval,format={c|asm},std
 *  name   : name to use for identifiers in the generated code.
             'image' is default (image_data, image_tiles).
 *  first  : number of the first tile to use for the image.
 *           0 is default.
 *  format : format of the generated source code (C or assembly).
 *           'asm' is default.
 *  std    : use 4 standard tiles (all white -> all black) located
 *           at 0xFD -> 0xFF. This is very useful when working with
 *           many images that use these tiles.
 */

/*
 * Example:
 *   xloadimage -dump gb,name=sky,first=10,format=c,std sky.c sky.gif
 */

# include <stdio.h>
# include <math.h>
# include <ctype.h>
# include "image.h"

#define NBSTDTILES 4

#define ASM_FORMAT 0
#define C_FORMAT   1

#define NL            fprintf(f, "\n");

#define BEGIN_COMMENT fprintf(f, format == ASM_FORMAT ? "\t; " : "/*\n * ")
#define END_COMMENT   fprintf(f, format == ASM_FORMAT ? "\n" : "\n */\n")
#define NL_COMMENT    fprintf(f, format == ASM_FORMAT ? "\n\t; " : "\n * ")
#define COMMENT(x)    fprintf(f, format == ASM_FORMAT ? \
			      "; %s\n" : "/* %s */\n", x)
#define IDENTIFIER(x) fprintf(f, format == ASM_FORMAT ? \
			      ".%s:\n" : "unsigned char %s[] = {\n", x)

typedef struct gbtile_ {
  byte bmap[8][2];
} gbtile;

gbtile tiles[0x100];

char buffer[128];

void gbDump(Image *image, char *options, char *filename, int verbose)
{
  FILE *f;
  byte *buf, *b;
  int i, j, h, w, c;
  int first, last;
  int format, std;
  gbtile t;
  byte *d;
  char *name, *value;
  char dataname[64];

  if(image->type != IRGB) {
    fprintf(stderr, "Image must have a color table (type = IRGB).\n");
    return;
  }

  if(image->depth != 2) {
    fprintf(stderr, "Image must have 4 colors (depth = 2).\n");
    return;
  }

  if((image->width % 8) != 0 || (image->height % 8) != 0) {
    fprintf(stderr, "Image must have dimensions multiple of 8.\n");
    return;
  }

  if(verbose) {
    printf("Dumping GB image to %s", filename);
    printf(" (size: %d - %d depth: %d)\n", image->width, image->height, image->depth);
  }

  if(!(f= fopen(filename, "w"))) {
    perror(filename);
    return;
  }

  first = 0;
  std = 0;
  format = ASM_FORMAT;
  strcpy(dataname, "image");
  while(getNextTypeOption(&options, &name, &value) > 0) {
    if(!strncmp("name", name, strlen(name))) {
      if(value)
	strcpy(dataname, value);
    } else if(!strncmp("first", name, strlen(name))) {
      first = (int)strtol(value, NULL, 16);
    } else if(!strncmp("format", name, strlen(name))) {
      if (!strncmp("c", value, strlen(value)))
	format = C_FORMAT;
      else if (!strncmp("asm", value, strlen(value)))
	format = ASM_FORMAT;
    } else if(!strncmp("std", name, strlen(name)))
      std = NBSTDTILES;
  }
  last = first;
  if(verbose) {
    printf("First tile is 0x%02x\n", first);
    printf("Dump format is %s\n", format == ASM_FORMAT ? "ASSEMBLY" : "C");
  }

  if(std) {
    /* Create the 4 basic tiles */
    for(i = 0; i < 8; i++) {
      tiles[0xFF].bmap[i][0] = tiles[0xFF].bmap[i][1] =
	tiles[0xFE].bmap[i][0] = tiles[0xFD].bmap[i][1] = 0x00;
      tiles[0xFD].bmap[i][0] = tiles[0xFE].bmap[i][1] =
	tiles[0xFC].bmap[i][0] = tiles[0xFC].bmap[i][1] = 0xFF;
    }
  }

  /* Create tiles list */
  buf = (byte *)lmalloc((image->width/8) * (image->height/8) * sizeof(byte));
  b = buf;
  d = image->data;
  for(h = 0; h < image->height; h += 8)
    for(w = 0; w < image->width; w += 8) {
      for(i = 0; i < 8; i++) {
	d = image->data + ((h + i) * image->width * image->pixlen) + w * image->pixlen;
	t.bmap[i][0] = t.bmap[i][1] = 0;
	for(j = 0; j < 8; j++) {
	  if(*d & 0x01)
	    t.bmap[i][0] |= (0x80 >> j);
	  if(*d & 0x02)
	    t.bmap[i][1] |= (0x80 >> j);
	  d += image->pixlen;
	}
      }
      for(c = 0x100 - std; c < 0x100; c++)
	if(memcmp(tiles[c].bmap, t.bmap, sizeof(t.bmap)) == 0)
	  break;
      if(c >= 0x100) {
	c = first;
	while(c < last) {
	  if(memcmp(tiles[c].bmap, t.bmap, sizeof(t.bmap)) == 0) {
	    break;
	  }
	  c++;
	}
	if(c == last) {
	  if(last >= 0x100 - std) {
	    fprintf(stderr, "Image has too much tiles.\n");
	    unlink(filename);
	    return;
	  }
	  memcpy(tiles[last].bmap, t.bmap, sizeof(t.bmap));
	  last++;
	}
      }
      *b = c;
      b++;
    }

  /* Write image info to file */
  BEGIN_COMMENT;
  if(image->title) {
    fprintf(f, "Image title: %s", image->title);
    NL_COMMENT;
  }
  fprintf(f, "Image size: 0x%02X x 0x%02X", image->width, image->height);
  NL_COMMENT;
  fprintf(f, "Number of tiles (total - unique): 0x%02X - 0x%02X",
	  (image->width / 8) * (image->height / 8), last - first);
  END_COMMENT;
  NL;

  /* Write image data to file */
  if(std) {
    IDENTIFIER("stdtiles_data");
    fprintf(f, "\t");
    COMMENT("Basic tiles (0xFC to 0xFF)");
    for(i = 0x100 - std; i < 0x100; i++) {
      fprintf(f, "\t");
      if(format == ASM_FORMAT)
	fprintf(f, ".byte\t");
      for(j = 0; j < 8; j++) {
	fprintf(f, "0x%02X,", tiles[i].bmap[j][0]);
	fprintf(f, "0x%02X", tiles[i].bmap[j][1]);
	if(j < 7 || (format == C_FORMAT && i < 0x100-1))
	  fprintf(f, ",");
      }
      fprintf(f, "\n");
    }
    if(format == C_FORMAT)
      fprintf(f, "};\n");
    NL;
  }

  sprintf(buffer, "%s_data", dataname);
  IDENTIFIER(buffer);
  i = first;
  while(i < last) {
    if(i == first || i % 8 == 0) {
      fprintf(f, "\n\t");
      sprintf(buffer, "Tile 0x%02X", i);
      COMMENT(buffer);
    }
    fprintf(f, "\t");
    if(format == ASM_FORMAT)
      fprintf(f, ".byte\t");
    for(j = 0; j < 8; j++) {
      fprintf(f, "0x%02X,", tiles[i].bmap[j][0]);
      fprintf(f, "0x%02X", tiles[i].bmap[j][1]);
      if(j < 7 || (format == C_FORMAT && i < last-1))
	fprintf(f, ",");
    }
    fprintf(f, "\n");
    i++;
  }
  if(format == C_FORMAT)
    fprintf(f, "};\n");
  NL;

  /* Write image table to file */
  sprintf(buffer, "%s_tiles", dataname);
  IDENTIFIER(buffer);
  b = buf;
  for(h = 0; h < image->height; h += 8) {
    fprintf(f, "\t");
    if(format == ASM_FORMAT)
      fprintf(f, ".byte\t");
    for(w = 0; w < image->width; w += 8) {
      fprintf(f, "0x%02X", *b);
      if(w < image->width-8 || (format == C_FORMAT && h < image->height-8))
	fprintf(f, ",");
      b++;
    }    
    fprintf(f, "\n");
  }
  if(format == C_FORMAT)
    fprintf(f, "};\n");
  fclose(f);
  lfree(buf);

  return;
}

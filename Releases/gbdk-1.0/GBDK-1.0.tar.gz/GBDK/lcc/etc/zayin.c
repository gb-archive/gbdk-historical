/* DEC ALPHAs running OSF/1 V3.2A (Rev. 17) at Princeton University */

#include <string.h>

char *cpp[] = {
/*	"/usr/local/lib/cpp", "-D__STDC__=1", */
	"/usr/gnu/lib/gcc-lib/alpha-dec-osf3.0/2.6.3/cpp", "-undef",
	"-DLANGUAGE_C", "-D__LANGUAGE_C__",
 	"-D_unix", "-D__unix__", "-D_osf", "-D__osf__",
	"-Dalpha", "-D_alpha", "-D__alpha",
	"-D__SYSTYPE_BSD",  "-D_SYSTYPE_BSD",
	"$1", "$2", "$3", 0 };
char *com[] =  { "/usr/local/lib/rcc", "-target=alpha-osf", "$1", "$2", "$3", "", 0 };
char *include[] = { "-I/usr/local/include/ansi", "-I/usr/include", 0 };
char *as[] =  { "/bin/as", "-o", "$3", "", "$1", "-nocpp", "$2", 0 };
char *ld[] =  { "/usr/bin/ld", "-o", "$3", "/usr/lib/cmplrs/cc/crt0.o",
	"$1", "$2", "", "", "-lm", "-lc", 0 };

int option(arg) char *arg; {
	if (strcmp(arg, "-g4") == 0
	&& access("/u/drh/lib/alpha/rcc", 4) == 0
	&& access("/u/drh/book/cdb/alpha/osf/cdbld", 4) == 0) {
		com[0] = "/u/drh/lib/alpha/rcc";
		com[5] = "-g4";
		ld[0] = "/u/drh/book/cdb/alpha/osf/cdbld";
		ld[1] = "-o";
		ld[2] = "$3";
		ld[3] = "$1";
		ld[4] = "$2";
		ld[5] = 0;
	} else if (strcmp(arg, "-g") == 0)
		return 1;
	else if (strcmp(arg, "-b") == 0 && access("/usr/local/lib/bbexit.o", 4) == 0)
		ld[6] = "/usr/local/lib/bbexit.o";
	else
		return 0;
	return 1;
}

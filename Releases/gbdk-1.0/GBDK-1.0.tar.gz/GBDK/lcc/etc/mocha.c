/* Sun4s running Solaris/SunOS 5.4 at Princeton University */

#include <string.h>

char *cpp[] = { "/usr/local/lib/cpp",
	"-D__STDC__=1", "-Dsparc", "-D__sparc__", "-Dsun", "-D__sun__",
	"$1", "$2", "$3", 0 };
char *include[] = { "-I/usr/local/include/ansi", "-I/usr/include", 0 };
char *com[] = { "/usr/local/lib/rcc", "-target=sparc-solaris",
	"$1", "$2", "$3", 0 };
char *as[] = { "/usr/ccs/bin/as", "-Qy", "-s", "-o", "$3", "$1", "$2", 0 };
char *ld[] = { "/usr/ccs/bin/ld", "-o", "$3", "$1",
	"/opt/SUNWspro/SC3.0.1/lib/crti.o", "/opt/SUNWspro/SC3.0.1/lib/crt1.o",
	"/opt/SUNWspro/SC3.0.1/lib/__fstd.o", "/opt/SUNWspro/SC3.0.1/lib/values-xt.o",
	"$2", "", "-Y", "P,/opt/SUNWspro/SC3.0.1/lib:/usr/ccs/lib:/usr/lib", "-Qy",
	"-lm", "-lc", "", "/opt/SUNWspro/SC3.0.1/lib/crtn.o", 0 };

int option(arg) char *arg; {
	if (strcmp(arg, "-g") == 0)
		ld[15] = "-lg";
	else if (strcmp(arg, "-b") == 0 && access("/usr/local/lib/bbexit.o", 4) == 0)
		ld[9] = "/usr/local/lib/bbexit.o";
	else
		return 0;
	return 1;
}

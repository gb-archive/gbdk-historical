/* DEC little-endian MIPSes running ULTRIX at Princeton University */

#include <string.h>

char *cpp[] = {
/*	"/usr/gnu/lib/gcc-cpp", "-undef",		/* GNU preprocessor */
	"/usr/local/lib/cpp", "-D__STDC__=1",		/* dmr's preprocessor */
	"-DLANGUAGE_C", "-D_LANGUAGE_C", "-D__LANGUAGE_C",
	"-D_unix", "-D__unix", "-Dultrix", "-D_ultrix", "-D__ultrix",
	"-Dmips", "-D_mips", "-D__mips",
	"-Dhost_mips", "-D_host_mips", "-D__host_mips",
	"-DMIPSEL", "-D_MIPSEL", "-D__MIPSEL",
	"$1", "$2", "$3", 0 };
char *com[] =  { "/usr/local/lib/rcc", "-target=mips-ultrix", "$1", "$2", "$3", "", 0 };
char *include[] = { "-I/usr/local/include/ansi", "-I/usr/include", 0 };
char *as[] =  { "/bin/as", "-o", "$3", "", "$1", "-nocpp", "-EL", "$2", 0 };
char *ld[] =  { "/usr/bin/ld", "-o", "$3", "/usr/lib/crt0.o", "$1", "$2", "", "", "-lm", "-lc", 0 };

static char *libprefix = "/cmnusr/local/lib/ldb/";
extern char *concat();

int option(arg) char *arg; {
	if (strcmp(arg, "-g4") == 0
	&& access("/u/drh/lib/mipsel/rcc", 4) == 0
	&& access("/u/drh/book/cdb/mips/ultrix/cdbld", 4) == 0) {
		com[0] = "/u/drh/lib/mipsel/rcc";
		com[5] = "-g4";
		ld[0] = "/u/drh/book/cdb/mips/ultrix/cdbld";
		ld[1] = "-o";
		ld[2] = "$3";
		ld[3] = "$1";
		ld[4] = "$2";
		ld[5] = 0;
	} else if (strcmp(arg, "-g") == 0)
		as[3] = "-g";
	else if (strcmp(arg, "-p") == 0 && strcmp(ld[3], "/usr/lib/crt0.o") == 0) {
		ld[3] = "/usr/lib/mcrt0.o";
		ld[7] = "/usr/lib/libprof1.a";
	} else if (strcmp(arg, "-b") == 0 && access("/usr/local/lib/bbexit.o", 4) == 0)
		ld[6] = "/usr/local/lib/bbexit.o";
	else if (strncmp(arg, "-B", 2) == 0)
		libprefix = arg + 2;
	else if (strcmp(arg, "-G") == 0 && strcmp(ld[3], "/usr/lib/crt0.o") == 0) {
	        com[0] = concat(libprefix, "mipsel/rcc");
		com[1] = "";
		ld[0]  = "/cmnusr/local/lib/ldb/ldb-ld";
   	        ld[3]  = concat(libprefix, "mipsel/crt0.o");
		ld[7]  = concat(libprefix, "mipsel/Cnub.o");
	} else
		return 0;
	return 1;
}

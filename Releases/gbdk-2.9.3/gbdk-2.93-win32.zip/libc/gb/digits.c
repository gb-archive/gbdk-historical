const char *digits = "0123456789ABCDEF";

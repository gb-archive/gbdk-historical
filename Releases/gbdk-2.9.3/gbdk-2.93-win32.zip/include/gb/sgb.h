#ifndef _SGB_H
#define _SGB_H

UINT8
sgb_check(void);
/* Return a non-null value if running on Super GameBoy */

#endif /* _SGB_H */

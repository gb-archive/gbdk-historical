/* avr.src/logic_cl.h */

  virtual int ori_Rd_K(t_mem code);
  virtual int andi_Rd_K(t_mem code);
  virtual int and_Rd_Rr(t_mem code);
  virtual int eor_Rd_Rr(t_mem code);
  virtual int or_Rd_Rr(t_mem code);

/* End of avr.src/logic_cl.h */

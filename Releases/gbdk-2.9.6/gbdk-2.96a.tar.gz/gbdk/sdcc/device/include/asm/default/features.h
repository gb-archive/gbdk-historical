/** Z80 specific features.
 */
#ifndef __SDC51_ASM_Z80_FEATURES_H
#define __SDC51_ASM_Z80_FEATURES_H   1

#define _REENTRANT	reentrant
#define _CODE		code

#endif

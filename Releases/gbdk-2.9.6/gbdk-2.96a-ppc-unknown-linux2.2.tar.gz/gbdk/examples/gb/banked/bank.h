#ifndef BANK_INCLUDE
#define BANK_INCLUDE

#include <stdio.h>

int bank2(int i) BANKED;
void bank3(void) BANKED;

#endif

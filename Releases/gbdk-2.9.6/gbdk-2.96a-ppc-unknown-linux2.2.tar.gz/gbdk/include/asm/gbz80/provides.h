#define USE_C_MEMCPY	1
#define USE_C_STRCPY	1
#define USE_C_STRCMP	1


/** Dumb stdio.h
    Z80 temp hack.
*/

void printf(const char *szFormat, ...);


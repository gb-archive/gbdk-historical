/* Silly string.h
 * Z80 specific hack
*/

#include <types.h>

char *strcpy(char *dest, const char *src);

int strcmp(const char *s1, const char *s2);

void *memcpy(void *dest, const void *src, WORD wLen);


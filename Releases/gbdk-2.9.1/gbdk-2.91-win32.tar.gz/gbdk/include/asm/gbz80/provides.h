#undef USE_C_MEMCPY
#undef USE_C_STRCPY
#undef USE_C_STRCMP

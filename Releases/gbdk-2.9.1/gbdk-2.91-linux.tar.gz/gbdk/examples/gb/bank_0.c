#include <gb/gb.h>

UBYTE var_0;  /* In external RAM bank 0 */

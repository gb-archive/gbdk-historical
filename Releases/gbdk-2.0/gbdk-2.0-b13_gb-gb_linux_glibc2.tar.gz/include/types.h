#ifndef _TYPES_H
#define _TYPES_H

typedef int                INT8;
typedef unsigned int       UINT8;
typedef long               INT16;
typedef unsigned long      UINT16;
typedef long long          INT32;
typedef unsigned long long UINT32;

typedef INT8               BYTE;
typedef UINT8              UBYTE;
typedef INT16              WORD;
typedef UINT16             UWORD;
typedef INT32              LWORD;
typedef UINT32             ULWORD;

typedef UINT16             POINTER;

#define	NULL     0

#define	FALSE    0
#define	TRUE     (!FALSE)

#endif /* _TYPES_H */

#include <sys/malloc.h>
#include <string.h>

void *calloc( UWORD nmem, UWORD size )
{
	void *malloced;

	malloced = malloc( nmem*size );
	if (malloced!=NULL) {
		memset( malloced, 0, nmem*size );
		return malloced;
	}
	return	NULL;
}

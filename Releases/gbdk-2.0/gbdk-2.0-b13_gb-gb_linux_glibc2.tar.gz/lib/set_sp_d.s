	.include	"global.s"

	.globl	.copy_vram

	.area	_CODE

_set_sprite_data::
	PUSH	BC

	LDA	HL,7(SP)	; Skip return address and registers
	LD	B,(HL)		; BC = data
	DEC	HL
	LD	C,(HL)
	DEC	HL
	LD	E,(HL)		; E = nb_tiles
	DEC	HL
	LD	A,(HL)		; A = first_tile

	LD	H,#0x00		; HL = nb_tiles
	LD	L,E
	ADD	HL,HL		; HL *= 16
	ADD	HL,HL
	ADD	HL,HL
	ADD	HL,HL
	LD	D,H		; DE = nb_tiles
	LD	E,L

	LD	H,#0x00		; HL = first_tile
	LD	L,A
	ADD	HL,HL		; HL *= 16
	ADD	HL,HL
	ADD	HL,HL
	ADD	HL,HL

	PUSH	BC
	LD	BC,#0x8000
	ADD	HL,BC
	POP	BC

	CALL	.copy_vram

	POP	BC
	RET

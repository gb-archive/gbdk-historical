	.include	"global.s"

	.globl	.copy_vram

	.area	_CODE

_set_bkg_data::
	PUSH	BC

	LDA	HL,7(SP)	; Skip return address and registers
	LD	B,(HL)		; BC = data
	DEC	HL
	LD	C,(HL)
	DEC	HL
	LD	E,(HL)		; E = nb_tiles
	DEC	HL
	LD	A,(HL)		; A = first_tile

	LD	H,#0x00		; HL = nb_tiles
	LD	L,E
	ADD	HL,HL		; HL *= 16
	ADD	HL,HL
	ADD	HL,HL
	ADD	HL,HL
	LD	D,H		; DE = nb_tiles
	LD	E,L

	LD	L,A		; HL = first_tile
	RLCA			; Sign extend (patterns have signed numbers)
	SBC	A
	LD	H,A
	ADD	HL,HL		; HL *= 16
	ADD	HL,HL
	ADD	HL,HL
	ADD	HL,HL

	PUSH	BC
	LD	BC,#0x9000
	ADD	HL,BC
	POP	BC

1$:				; Special version of '.copy_vram'
	BIT	3,H		; Bigger than 0x9800
	JR	Z,2$
	BIT	4,H
	JR	Z,2$
	RES	4,H		; Switch to 0x8800
2$:
	LDH	A,(.STAT)
	AND	#0x02
	JR	NZ,2$

	LD	A,(BC)
	LD	(HL+),A
	INC	BC
	DEC	DE
	LD	A,D
	OR	E
	JR	NZ,1$

	POP	BC
	RET

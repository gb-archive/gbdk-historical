#ifndef _GB_H
#define _GB_H

#include <types.h>
#include <hardware.h>

/* Joypad */

#define	J_START      0x80U
#define	J_SELECT     0x40U
#define	J_B          0x20U
#define	J_A          0x10U
#define	J_DOWN       0x08U
#define	J_UP         0x04U
#define	J_LEFT       0x02U
#define	J_RIGHT      0x01U

/* Modes */

#define	M_DRAWING    0x01U
#define	M_TEXT_OUT   0x02U
#define	M_TEXT_INOUT 0x03U

/* Sprite properties bits */

#define S_PALETTE    0x10U
#define S_FLIPX      0x20U
#define S_FLIPY      0x40U
#define S_PRIORITY   0x80U

/* Interrupt flags */

#define VBL_IFLAG    0x01U
#define LCD_IFLAG    0x02U
#define TIM_IFLAG    0x04U
#define SIO_IFLAG    0x08U
#define JOY_IFLAG    0x10U

/* Limits */

#define SCREENWIDTH  0xA0U
#define SCREENHEIGHT 0x90U
#define MINWNDPOSX   0x07U
#define MINWNDPOSY   0x00U
#define MAXWNDPOSX   0xA6U
#define MAXWNDPOSY   0x8FU

/* ************************************************************ */

/*
 * IRQ handlers
 */
typedef void (*int_handler)(void);

void
add_VBL(int_handler h);

void
add_LCD(int_handler h);

void
add_TIM(int_handler h);

void
add_SIO(int_handler h);

void
add_JOY(int_handler h);

/* ************************************************************ */

void
mode(UBYTE m);

/* GB type (GB, PGB, CGB) */
extern UBYTE _cpu;

#define DMG_TYPE 0x01 /* Original GB or Super GB */
#define MGB_TYPE 0xFF /* Pocket GB or Super GB 2 */
#define CGB_TYPE 0x11 /* Color GB */

/* ************************************************************ */

void
send_byte(void);
/* Send byte in _io_out to the serial port */

void
receive_byte(void);
/* Receive byte from the serial port in _io_in */

extern UBYTE _io_status;
extern UBYTE _io_in;
extern UBYTE _io_out;

/* Status codes */
#define IO_IDLE			0x00U		/* IO is completed */
#define IO_SENDING		0x01U		/* Sending data */
#define IO_RECEIVING	0x02U		/* Receiving data */
#define IO_ERROR		0x04U		/* Error */

/* ************************************************************ */

void
switch_rom_bank(UBYTE b);

void
switch_ram_bank(UBYTE b);

/* ************************************************************ */

void
delay(UWORD d);

/* ************************************************************ */

UBYTE
joypad(void);

UBYTE
waitpad(UBYTE mask);

void
waitpadup(void);

/* ************************************************************ */

void
enable_interrupts(void);

void
disable_interrupts(void);

void
set_interrupts(UBYTE flags);

void
reset(void);

void
wait_vbl(void);

/* ************************************************************ */

void
hiramcpy(UBYTE dst,
	 const void *src,
	 UBYTE n);

/* ************************************************************ */

#define DISPLAY_ON \
  LCDC_REG|=0x80U

#define DISPLAY_OFF \
  wait_vbl(); \
  LCDC_REG&=0x7FU

#define SHOW_BKG \
  LCDC_REG|=0x01U

#define HIDE_BKG \
  LCDC_REG&=0xFEU

#define SHOW_WIN \
  LCDC_REG|=0x20U

#define HIDE_WIN \
  LCDC_REG&=0xDFU

#define SHOW_SPRITES \
  LCDC_REG|=0x02U

#define HIDE_SPRITES \
  LCDC_REG&=0xFDU

#define SPRITES_8x16 \
  LCDC_REG|=0x04U

#define SPRITES_8x8 \
  LCDC_REG&=0xFBU

/* ************************************************************ */

void
set_bkg_data(UBYTE first_tile,
	     UBYTE nb_tiles,
	     unsigned char *data);
/* 0 <= first_tile <= 255
 * 0 <= first_tile+nb_tiles <= 255
 * nb_tiles >= 1
 *
 * Assumes that background data are at [0x8800;0x97FF]
 *  (signed, i.e. tiles 0x00 to 0x7F are at [0x9000;0x97FF])
 */

void
set_bkg_tiles(UBYTE x,
	      UBYTE y,
	      UBYTE w,
	      UBYTE h,
	      unsigned char *tilelist);
/* 0 <= x <= 31
 * 0 <= y <= 31
 * 1 <= w <= 32-x
 * 1 <= h <= 32-y
 *
 * Assumes that background tiles are at [0x9800;0x9BFF]
 */

void
get_bkg_tiles(UBYTE x,
	      UBYTE y,
	      UBYTE w,
	      UBYTE h,
	      unsigned char *buffer);
/* 0 <= x <= 31
 * 0 <= y <= 31
 * 1 <= w <= 32-x
 * 1 <= h <= 32-y
 *
 * Assumes that background tiles are at [0x9800;0x9BFF]
 */

void
scroll_bkg(UBYTE x,
	   UBYTE y);

/* ************************************************************ */

void
set_win_data(UBYTE first_tile,
	     UBYTE nb_tiles,
	     unsigned char *data);
/* 0 <= first_tile <= 255
 * 0 <= first_tile+nb_tiles <= 255
 * nb_tiles >= 1
 *
 * Window data are always at [0x8800;0x97FF]
 *  (signed, i.e. tiles 0x00 to 0x7F are at [0x9000;0x97FF])
 */

void
set_win_tiles(UBYTE x,
	      UBYTE y,
	      UBYTE w,
	      UBYTE h,
	      unsigned char *tilelist);
/* 0 <= x <= 31
 * 0 <= y <= 31
 * 1 <= w <= 32-x
 * 1 <= h <= 32-y
 *
 * Assumes that window tiles are at [0x9C00;0x9FFF]
 */

void
scroll_win(UBYTE x,
	   UBYTE y);

/* ************************************************************ */

void
set_sprite_data(UBYTE first_tile,
		UBYTE nb_tiles,
		unsigned char *data);
/* 0 <= first_tile <= 255
 * 0 <= first_tile+nb_tiles <= 255
 * nb_tiles >= 1
 *
 * Sprite data are always at [0x8000;0x8FFF]
 */

void
set_sprite_tile(UBYTE nb,
		UBYTE tile);
/* 0 <= nb <= 39
 * 0 <= tile <= 255
 */

void
set_sprite_prop(UBYTE nb,
		UBYTE prop);
/* 0 <= nb <= 39
 */

void
move_sprite(UBYTE nb,
	    UBYTE x,
	    UBYTE y);
/* 0 <= nb <= 39
 * 0 <= x <= 255
 * 0 <= y <= 255
 */

/* ************************************************************ */

void
set_data(UWORD dst,
	 unsigned char *src,
	 UWORD len);

void
get_data(unsigned char *dst,
	 UWORD src,
	 UWORD len);

void
set_tiles(UBYTE x,
	  UBYTE y,
	  UBYTE w,
	  UBYTE h,
	  UWORD dst,
	  unsigned char *src);

void
get_tiles(UBYTE x,
	  UBYTE y,
	  UBYTE w,
	  UBYTE h,
	  unsigned char *dst,
	  UWORD src);

#endif /* _GB_H */

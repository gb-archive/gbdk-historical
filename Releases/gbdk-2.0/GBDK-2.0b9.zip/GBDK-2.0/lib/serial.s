		.include		"global.s"

		.area	_CODE

		;; Send byte in __io_out to the serial port
.send_byte:
_send_byte::
		LD		A,#.IO_BUSY
		LD		(__io_status),A	; Store status
		LD		A,#.ST_INITIATING
		LD		(.io_state),A	; Initiating send
		LD		A,#0x01
		LDH		(.SC),A			; Use internal clock
		LD		A,#.DT_START
		LDH		(.SB),A			; Start tranfer
		LD		A,#0x81
		LDH		(.SC),A			; Use internal clock
		RET

		;; Receive byte from the serial port in __io_in
.receive_byte:
_receive_byte::
		LD		A,#.IO_BUSY
		LD		(__io_status),A	; Store status
		LD		A,#.ST_LISTENING
		LD		(.io_state),A	; Listening to data
		XOR		A
		LDH		(.SC),A			; Use external clock
		LD		A,#.DT_LISTENING
		LDH		(.SB),A			; Send LISTENING byte
		LD		A,#0x80
		LDH		(.SC),A			; Use external clock
		RET

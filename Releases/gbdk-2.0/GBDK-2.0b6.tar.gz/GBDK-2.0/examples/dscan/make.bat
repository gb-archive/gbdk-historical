..\..\bin\lcc -Wa-l -Wl-m -o dscan.gb dscan.c

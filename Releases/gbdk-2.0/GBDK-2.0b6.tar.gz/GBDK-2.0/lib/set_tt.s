		.include		"global.s"

		.area	_CODE

		;; Initialize part (size = DE) of the tile set from (BC) to (HL)
.set_tiles::
1$:
		LDH		A,(.STAT)
		AND		#0x02
		JR		NZ,1$

		LD		A,(BC)
		LD		(HL+),A
		INC		BC
		DEC		DE
		LD		A,D
		OR		E
		JR		NZ,1$
		RET
		;; Set window tile table to table starting at (BC)
.set_wtt::
		LD		HL,#.WTT
		JR		.set_tt
		;; Set background tile table to table starting at (BC)
.set_btt::
		LD		HL,#.BTT
.set_tt::
		LD		DE,#0x0400		; One whole GB Screen
		JP		.set_tiles

_set_data::
		PUSH	BC

		LDA		HL,9(SP)		; Skip return address and registers
		LD		D,(HL)			; DE = len
		DEC		HL
		LD		E,(HL)
		DEC		HL
		LD		B,(HL)			; BC = data
		DEC		HL
		LD		C,(HL)
		DEC		HL
		LD		A,(HL-)			; HL = addr
		LD		H,(HL)
		LD		L,A

		CALL	.set_tiles

		POP		BC
		RET

#include <stdio.h>

UBYTE sprint(char *s, char *str)
{
  UBYTE pos = 0;

  while(*str)
    s[pos++] = *str++;
  s[pos] = 0;

  return pos;
}

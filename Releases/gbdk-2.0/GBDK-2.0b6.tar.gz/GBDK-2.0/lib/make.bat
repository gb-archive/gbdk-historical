..\bin\lcc -Wa-l -c -o crt0.o crt0.s

..\bin\lcc -Wa-l -c -o asl.o asl.s
..\bin\lcc -Wa-l -c -o asr.o asr.s
..\bin\lcc -Wa-l -c -o div.o div.s
..\bin\lcc -Wa-l -c -o lsr.o lsr.s
..\bin\lcc -Wa-l -c -o mul.o mul.s

..\bin\lcc -Wa-l -c -o delay.o delay.s
..\bin\lcc -Wa-l -c -o get_xy_tt.o get_xy_tt.s
..\bin\lcc -Wa-l -c -o hiramcpy.o hiramcpy.s
..\bin\lcc -Wa-l -c -o init_tt.o init_tt.s
..\bin\lcc -Wa-l -c -o mv_sprite.o mv_sprite.s
..\bin\lcc -Wa-l -c -o pad.o pad.s
..\bin\lcc -Wa-l -c -o prop_sprite.o prop_sprite.s
..\bin\lcc -Wa-l -c -o scroll_bkg.o scroll_bkg.s
..\bin\lcc -Wa-l -c -o scroll_win.o scroll_win.s
..\bin\lcc -Wa-l -c -o set_bkg_data.o set_bkg_data.s
..\bin\lcc -Wa-l -c -o set_bkg_tiles.o set_bkg_tiles.s
..\bin\lcc -Wa-l -c -o set_sprite.o set_sprite.s
..\bin\lcc -Wa-l -c -o set_sprite_data.o set_sprite_data.s
..\bin\lcc -Wa-l -c -o set_tt.o set_tt.s
..\bin\lcc -Wa-l -c -o set_win_data.o set_win_data.s
..\bin\lcc -Wa-l -c -o set_win_tiles.o set_win_tiles.s
..\bin\lcc -Wa-l -c -o set_xy_tt.o set_xy_tt.s

..\bin\lcc -Wa-l -c -o input.o input.s
..\bin\lcc -Wa-l -c -o output.o output.s

..\bin\lcc -Wa-l -c -o drawing.o drawing.s

..\bin\lcc -Wa-l -c -o memcpy.o memcpy.s

..\bin\lcc -Wa-l -c -o abs.o abs.c
..\bin\lcc -Wa-l -c -o atoi.o atoi.c
..\bin\lcc -Wa-l -c -o atol.o atol.c
..\bin\lcc -Wa-l -c -o digits.o digits.c
..\bin\lcc -Wa-l -c -o isalpha.o isalpha.c
..\bin\lcc -Wa-l -c -o isdigit.o isdigit.c
..\bin\lcc -Wa-l -c -o islower.o islower.c
..\bin\lcc -Wa-l -c -o isspace.o isspace.c
..\bin\lcc -Wa-l -c -o isupper.o isupper.c
..\bin\lcc -Wa-l -c -o itoa.o itoa.c
..\bin\lcc -Wa-l -c -o lasb.o lasb.c
..\bin\lcc -Wa-l -c -o ltoa.o ltoa.c
..\bin\lcc -Wa-l -c -o print.o print.c
..\bin\lcc -Wa-l -c -o printf.o printf.c
..\bin\lcc -Wa-l -c -o println.o println.c
..\bin\lcc -Wa-l -c -o printn.o printn.c
..\bin\lcc -Wa-l -c -o puts.o puts.c
..\bin\lcc -Wa-l -c -o scanf.o scanf.c
..\bin\lcc -Wa-l -c -o sprint.o print.c
..\bin\lcc -Wa-l -c -o sprintf.o printf.c
..\bin\lcc -Wa-l -c -o sprintln.o println.c
..\bin\lcc -Wa-l -c -o sprintn.o printn.c
..\bin\lcc -Wa-l -c -o strcat.o strcat.c
..\bin\lcc -Wa-l -c -o strcmp.o strcmp.c
..\bin\lcc -Wa-l -c -o strcpy.o strcpy.c
..\bin\lcc -Wa-l -c -o strlen.o strlen.c
..\bin\lcc -Wa-l -c -o strncat.o strncat.c
..\bin\lcc -Wa-l -c -o strncmp.o strncmp.c
..\bin\lcc -Wa-l -c -o strncpy.o strncpy.c
..\bin\lcc -Wa-l -c -o tolower.o tolower.c
..\bin\lcc -Wa-l -c -o toupper.o toupper.c

#include <stdio.h>
#include <stdlib.h>

static char rcsid[] = "$Id: yynull.c,v 1.2 1997/05/22 22:46:51 drh Exp $";

void _YYnull(char *file, int line) {
	fprintf(stderr, "null pointer dereferenced:");
	if (file)
		fprintf(stderr, " file %s,", file);
	fprintf(stderr, " line %d\n", line);
	fflush(stderr);
	abort();
}

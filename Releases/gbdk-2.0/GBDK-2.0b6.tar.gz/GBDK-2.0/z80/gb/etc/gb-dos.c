/* DOS */

#ifndef LCCDIR
#define LCCDIR "\\GBDK-2.0\\"
#endif

#include <string.h>

char *suffixes[] = { ".c;.C", ".i;.I", ".s;.S;.asm;.ASM", ".o;.O;.obj;.OBJ", ".exe", 0 };
char inputs[256] = "";
char *cpp[] = { LCCDIR "bin\\cpp",
	"-D__STDC__=1", "-DZ80", "-DGB", "$1", "$2", "$3", 0 };
char *include[] = { "-I" LCCDIR "include", 0 };
/* The 2nd argument of com must contain "win32" for DOS compilation... */
char *com[] = { LCCDIR "bin\\rcc", "-g_win32", "-target=z80/gb",
	"$1", "$2", "$3", 0 };
char *as[] = { LCCDIR "bin\\asGB", "-o", "$1", "$3", "$2", 0 };
char *ld[] = { LCCDIR "bin\\linkGB", "-n", "--", "-z", "$1",
	"-k" LCCDIR "lib\\", "-lgb.lib", "$3", LCCDIR "lib\\crt0.o", "$2", 0 };

extern char *concat(char *, char *);

int option(char *arg) {
	if(strncmp(arg, "-lccdir=", 8) == 0) {
		cpp[0] = concat(&arg[8], "\\bin\\cpp");
		include[0] = concat("-I", concat(&arg[8], "\\include"));
		com[0] = concat(&arg[8], "\\bin\\rcc");
		as[0] = concat(&arg[8], "\\bin\\asGB");
		ld[0] = concat(&arg[8], "\\bin\\linkGB");
		ld[5] = concat("-k", concat(&arg[8], "\\lib\\"));
		ld[8] = concat(&arg[8], "\\lib\\crt0.o");
	} else
		return 0;
	return 1;
}

/*
 * Optimizer for the GameBoy Z80-like processor
 */

#define EQUALS(s1,s2)  (s1 == s2 || (s1 != NULL && s2 != NULL && strcasecmp(s1, s2) == 0))

typedef struct op_ {
  char *label;
  char *opc;
  char *arg1;
  char *arg2;
  char *comment;
  struct op_ *next;
  struct op_ *prev;
} op;

typedef struct blk_ {
  char *addr;
  struct blk_ *next;
} blk;

void add_op(char *label, char *opc, char *arg1, char *arg2, char *comment);
void label(char *label);
void op0(char *opc);
void op1(char *opc, char *arg1);
void op2(char *opc, char *arg1, char *arg2);
void comment(char *comment);
char *str_alloc(const char *fmt, ...);
op *next_op(op *o);
void remove_op(op *o);
void optimize_op(op *o);
void generate();

static blk *root_blk = NULL, *last_blk = NULL;
static op *root_op = NULL, *last_op = NULL;
static int rule1 = 0;
static int rule2 = 0;

void add_op(char *label, char *opc, char *arg1, char *arg2, char *comment)
{
  if(root_op == NULL) {
	root_op = last_op = (op *)malloc(sizeof(op));
	last_op->prev = NULL;
  } else {
	last_op->next = (op *)malloc(sizeof(op));
	last_op->next->prev = last_op;
	last_op = last_op->next;
  }
  last_op->label = label;
  last_op->opc = opc;
  last_op->arg1 = arg1;
  last_op->arg2 = arg2;
  last_op->comment = comment;
  last_op->next = NULL;

  if(label != NULL)
	generate();
}

void label(char *label)
{
  add_op(label, NULL, NULL, NULL, NULL);
}

void op0(char *opc)
{
  add_op(NULL, opc, NULL, NULL, NULL);
}

void op1(char *opc, char *arg1)
{
  add_op(NULL, opc, arg1, NULL, NULL);
}

void op2(char *opc, char *arg1, char *arg2)
{
  add_op(NULL, opc, arg1, arg2, NULL);
}

void comment(char *comment)
{
  add_op(NULL, NULL, NULL, NULL, comment);
}

char *str_alloc(const char *fmt, ...)
{
  char s[128];
  va_list ap;

  va_start(ap, fmt);
  vsprintf(s, fmt, ap);
  va_end(ap);
  if(root_blk == NULL) {
	root_blk = last_blk = (blk *)malloc(sizeof(blk));
  } else {
	last_blk->next = (blk *)malloc(sizeof(blk));
	last_blk = last_blk->next;
  }
  last_blk->addr = (char *)malloc(strlen(s) + 1);
  last_blk->next = NULL;
  strcpy(last_blk->addr, s);
  return last_blk->addr;
}

op *next_op(op *o)
{
  op *next;

  if(o == NULL)
	return NULL;
  next = o->next;
  while(next) {
	if(next->opc != NULL)
	  break;
	next = next->next;
  }
  return next;
}

void remove_op(op *o)
{
  if(o == root_op)
	root_op = o->next;
  if(o == last_op)
	last_op = o->prev;
  if(o->next != NULL)
	o->next->prev = o->prev;
  if(o->prev != NULL)
	o->prev->next = o->next;
  free(o);
}

void optimize_op(op *o)
{
  /* Optimize unnecessary moves */
  if(EQUALS(o->opc, "LD")) {
	op *next;

	next = next_op(o);
	if(next != NULL &&
	   EQUALS(next->arg1, o->arg2) &&
	   EQUALS(next->arg2, o->arg1) &&
	   !EQUALS(o->arg1, "(HL+)") &&
	   !EQUALS(o->arg1, "(HL-)") &&
	   !EQUALS(o->arg2, "(HL+)") &&
	   !EQUALS(o->arg2, "(HL-)")) {
	  remove_op(next);
	  rule1++;
	}
  } else if(EQUALS(o->opc, "LDA") &&
			EQUALS(o->arg1, "HL")) {
	op *next1, *next2, *next3;

	next1 = next_op(o);
	next2 = next_op(next1);
	next3 = next_op(next2);

	if(next1 != NULL &&
	   next2 != NULL &&
	   next3 != NULL &&

	   EQUALS(next2->opc, o->opc) &&
	   EQUALS(next2->arg1, o->arg1) &&
	   EQUALS(next2->arg2, o->arg2) &&

	   EQUALS(next1->opc, "LD") &&
	   (EQUALS(next1->arg1, "(HL)") ||
		EQUALS(next1->arg2, "(HL)")) &&
	   !(EQUALS(next1->arg1, "H") ||
		 EQUALS(next1->arg1, "L") ||
		 EQUALS(next1->arg2, "H") ||
		 EQUALS(next1->arg2, "L")) &&

	   EQUALS(next3->opc, next1->opc) &&
	   EQUALS(next3->arg1, next1->arg2) &&
	   EQUALS(next3->arg2, next1->arg1)) {
	  remove_op(next2);
	  remove_op(next3);
	  rule2++;
	}
  }
}

void generate()
{
  op *o;
  blk *b;

  if(optimize) {
	o = root_op;
	while(o != NULL) {
	  optimize_op(o);
	  o = o->next;
	}
  }

  o = root_op;
  while(o != NULL) {
	if(o->label != NULL)
	  print(o->label);
	if(o->opc != NULL)
	  print("\t%s", o->opc);
	if(o->arg1 != NULL) {
	  print("\t%s", o->arg1);
	  if(o->arg2 != NULL)
		print(",%s", o->arg2);
	}
	if(o->comment != NULL)
	  print("\t;; %s", o->comment);
	print("\n");
	root_op = o;
	o = o->next;
	free(root_op);
  }
  root_op = last_op = NULL;

  b = root_blk;
  while(b != NULL) {
	free(b->addr);
	root_blk = b;
	b = b->next;
	free(root_blk);
  }
  root_blk = last_blk = NULL;
}

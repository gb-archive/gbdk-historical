		.include		"global.s"

		.area	_CODE

		;; Initialize part (size = DE) of the tile set at (HL) with B
.init_tiles::
1$:
		LDH		A,(.STAT)
		AND		#0x02
		JR		NZ,1$

		LD		(HL),B
		INC		HL
		DEC		DE
		LD		A,D
		OR		E
		JR		NZ,1$
		RET
		;; Initialize window tile table with B
.init_wtt::
		LD		HL,#.WTT
		JR		.init_tt
		;; Initialize background tile table with B
.init_btt::
		LD		HL,#.BTT
.init_tt::
		LD		DE,#0x0400		; One whole GB Screen
		JP		.init_tiles

		.include		"global.s"

		;; ****************************************
		;; Beginning of module
		.title	"GB Runtime"
		.module	Runtime
		.area	_HEADER (ABS)

		;; Standard header for the GB
		.org	0x00
		RET						; Empty function (default for IRQs)

		;; IRQ vectors
		.org	0x40			; VBL
		JP		.irq_0x40

		.org	0x48			; LCD
		JP		.irq_0x48

		.org	0x50			; TIM
		JP		.irq_0x50

		.org	0x58			; SIO
		JP		.irq_0x58

		.org	0x60			; JOY
		JP		.irq_0x60

.irq_0x40:
		PUSH	AF
		PUSH	BC
		PUSH	DE
		PUSH	HL
		CALL	.irq_VBL
		POP		HL
		POP		DE
		POP		BC
		POP		AF
		RETI

.irq_0x48:
		PUSH	AF
		PUSH	BC
		PUSH	DE
		PUSH	HL
		CALL	.irq_LCD
		POP		HL
		POP		DE
		POP		BC
		POP		AF
		RETI

.irq_0x50:
		PUSH	AF
		PUSH	BC
		PUSH	DE
		PUSH	HL
		CALL	.irq_TIM
		POP		HL
		POP		DE
		POP		BC
		POP		AF
		RETI

.irq_0x58:
		PUSH	AF
		PUSH	BC
		PUSH	DE
		PUSH	HL
		CALL	.irq_SIO
		POP		HL
		POP		DE
		POP		BC
		POP		AF
		RETI

.irq_0x60:
		PUSH	AF
		PUSH	BC
		PUSH	DE
		PUSH	HL
		CALL	.irq_JOY
		POP		HL
		POP		DE
		POP		BC
		POP		AF
		RETI

		;; GameBoy Header

		;; DO NOT CHANGE...
		.org	0x100
		NOP
		JP		0x150
		.byte	0xCE,0xED,0x66,0x66
		.byte	0xCC,0x0D,0x00,0x0B
		.byte	0x03,0x73,0x00,0x83
		.byte	0x00,0x0C,0x00,0x0D
		.byte	0x00,0x08,0x11,0x1F
		.byte	0x88,0x89,0x00,0x0E
		.byte	0xDC,0xCC,0x6E,0xE6
		.byte	0xDD,0xDD,0xD9,0x99
		.byte	0xBB,0xBB,0x67,0x63
		.byte	0x6E,0x0E,0xEC,0xCC
		.byte	0xDD,0xDC,0x99,0x9F
		.byte	0xBB,0xB9,0x33,0x3E

		;; Title of the game
		.org	0x134
		.asciz	"Title"

		;; Cartridge type is ROM only
		.org	0x147
		.byte	0

		;; ROM size is 32kB
		.org	0x148
		.byte	0

		;; RAM size is 0kB
		.org	0x149
		.byte	0

		;; Maker ID
		.org	0x14A
		.byte	0x00,0x00

		;; Version number
		.org	0x14C
		.byte	0x01

		;; Complement check
		.org	0x14D
		.byte	0x00

		;; Checksum
		.org	0x14E
		.byte	0x00,0x00

		;; ****************************************
		.org	0x150
		;; Beginning of the code
		DI						; Disable interrupts
		;; Initialize the stack
		LD		SP,#.STACK
		XOR		A
		LDH		(.SCY),A
		LDH		(.SCX),A
		LDH		(.STAT),A
		LDH		(.WY),A
		LD		A,#0x07
		LDH		(.WX),A
		;; Ensure the screen is turned on
		LD		A,#0b11000000	; LCD			= On
								; WindowBank	= 0x9C00
								; Window		= Off
								; BG Chr		= 0x8800
								; BG Bank		= 0x9800
								; OBJ			= 8x8
								; OBJ			= Off
								; BG			= Off
		LDH		(.LCDC),A
		;; Must be in VBL before turning the screen off
		CALL	.wait_vbl

		;; Turn the screen off
		LD		A,#0b01000000	; LCD			= Off
								; WindowBank	= 0x9C00
								; Window		= Off
								; BG Chr		= 0x8800
								; BG Bank		= 0x9800
								; OBJ			= 8x8
								; OBJ			= Off
								; BG			= Off
		LDH		(.LCDC),A
		;; Initialize the MBC
		LD		A,#0x0A
		LD		(0x0000),A
		;; ROM bank 1
		LD		A,#0x01
		LD		(0x2000),A
		XOR		A
		LD		(.mode),A
		;; Clear from 0xC000 to 0xDFFF
		LD		HL,#0xDFFF
		LD		C,#0x20
		LD		B,#0x00
1$:
		LD		(HL-),A
		DEC		B
		JR		NZ,1$
		DEC		C
		JR		NZ,1$
		;; Clear from 0xFE00 to 0xFEFF
		LD		HL,#0xFEFF
		LD		B,#0x00
2$:
		LD		(HL-),A
		DEC		B
		JR		NZ,2$
		;; Clear from 0xFF8F to 0xFFFE
		LD		HL,#0xFFFE
		LD		B,#0x80
3$:
		LD		(HL-),A
		DEC		B
		JR		NZ,3$
		;; Clear OAM
		CALL	.clear_OAM
		;; Copy refresh_OAM routine to HIRAM
		LD		BC,#.refresh_OAM
		LD		HL,#.start_refresh_OAM
		LD		B,#.end_refresh_OAM-.start_refresh_OAM
4$:
		LD		A,(HL+)
		LDH		(C),A
		INC		C
		DEC		B
		JR		NZ,4$
		;; Standard color palettes
		LD		A,#0b11100100	; Grey 3 = 11 (Black)
								; Grey 2 = 10 (Dark grey)
								; Grey 1 = 01 (Light grey)
								; Grey 0 = 00 (Transparent)
		LDH		(.BGP),A
		LDH		(.OBP0),A
		LD		A,#0b00011011
		LDH		(.OBP1),A

		;; Turn the screen on
		LD		A,#0b11000000	; LCD			= On
								; WindowBank	= 0x9C00
								; Window		= Off
								; BG Chr		= 0x8800
								; BG Bank		= 0x9800
								; OBJ			= 8x8
								; OBJ			= Off
								; BG			= Off
		LDH		(.LCDC),A
		XOR		A
		LDH		(.IF),A
		LD		A,#0x09			; Pin P10-P13	=	Off
								; Serial I/O	=	On
								; Timer Ovfl	=	Off
								; LCDC			=	Off
								; V-Blank		=	On
		LDH		(.IE),A

		XOR		A
		LDH		(.SC),A			; Use external clock
		LD		A,#.DT_IDLE
		LDH		(.SB),A			; Send IDLE byte
		LD		A,#0x80
		LDH		(.SC),A			; Use external clock

		CALL	.init

		EI						; Enable interrupts

		;; Call the main function
		CALL	_main

99$:
		JR		99$				; Wait forever

		.org	.MODE_TABLE
		;; Jump table for modes
		RET

		;; ****************************************

		;; Ordering of segments for the linker
		.area	_CODE
		.area	_DATA
		.area	_LIT
		.area	_BSS

.mode::
		.ds		0x01			; Current mode
__io_out::
		.ds		0x01			; Byte to send
__io_in::
		.ds		0x01			; Received byte
__io_status::
		.ds		0x01			; Status of serial IO

		;; Runtime library
		.area	_CODE

		;; Call the initialization function for the mode specified in HL
.set_mode::
		LD		A,L
		LD		(.mode),A

		LD		BC,#.MODE_TABLE
		SLA		L				; Multiply mode by 4
		SLA		L
		ADD		HL,BC
		JP		(HL)			; Jump to initialization routine

		;; Wait for VBL
.wait_vbl::
_wait_vbl::
		;; Check if the screen is on
		LDH		A,(.LCDC)
		ADD		A
		RET		NC				; Return if screen is off
1$:
		LDH		A,(.LY)
		CP		#0x91			; Bigger than 0x90?
		JR		NZ,1$			; Loop until equals to 0x91
		RET

		;; Clear OAM data
.clear_OAM::
		LD		B,#0xA0			; Clear OAM
		LD		HL,#.OAM
		XOR		A
1$:
		LD		(HL+),A
		DEC		B
		JR		NZ,1$
		RET

		;; Copy OAM data to OAM RAM
.start_refresh_OAM:
		LD		HL,#.OAM		; OAM data address
		LD		A,H
;		LD		A,#>.OAM		; The linker does not allow this (with '.OAM' relocatable)...
		LDH		(.DMA),A		; Put A into DMA registers
		LD		A,#0x28			; We need to wait 160 ns
1$:
		DEC		A
		JR		NZ,1$
		RET
.end_refresh_OAM:

.serial_IO::
		LD		A,(__io_status)	; Get status

		CP		#.IO_RECEIVING
		JR		NZ,10$

		;; Receiving data
		LDH		A,(.SB)			; Get data byte
		LD		(__io_in),A		; Store it
		LD		A,#.IO_IDLE
		JR		11$

10$:

		CP		#.IO_SENDING
		JR		NZ,99$

		;; Sending data
		LDH		A,(.SB)			; Get data byte
		CP		#.DT_RECEIVING
		JR		Z,11$
		LD		A,#.IO_ERROR
		JR		12$
11$:
		LD		A,#.IO_IDLE
12$:
		LD		(__io_status),A	; Store status

		XOR		A
		LDH		(.SC),A			; Use external clock
		LD		A,#.DT_IDLE
		LDH		(.SB),A			; Reply with IDLE byte
99$:
		LD		A,#0x80
		LDH		(.SC),A			; Enable transfer with external clock
		RET

_mode::
		LDA		HL,2(SP)		; Skip return address
		LD		L,(HL)
		LD		H,#0x00
		CALL	.set_mode
		RET

_switch_rom_bank::
		LDA		HL,2(SP)		; Skip return address
		LD		A,(HL)
		LD		(0x2000),A
		RET

_switch_ram_bank::
		LDA		HL,2(SP)		; Skip return address
		LD		A,(HL)
		LD		(0x4000),A
		RET

_enable_interrupts::
		EI
		RET

_disable_interrupts::
		DI
		RET

_set_interrupts::
		DI
		LDA		HL,2(SP)		; Skip return address
		XOR		A
		LDH		(.IF),A
		LD		A,(HL)
		LDH		(.IE),A
		EI						; Enable interrupts
		RET

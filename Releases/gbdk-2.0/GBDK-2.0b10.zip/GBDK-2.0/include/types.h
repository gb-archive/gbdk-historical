#ifndef _TYPES_H
#define _TYPES_H

typedef int           BYTE;
typedef unsigned int  UBYTE;
typedef long          WORD;
typedef unsigned long UWORD;
typedef unsigned long POINTER;

#define	NULL     0

#define	FALSE    0
#define	TRUE     1

#endif /* _TYPES_H */

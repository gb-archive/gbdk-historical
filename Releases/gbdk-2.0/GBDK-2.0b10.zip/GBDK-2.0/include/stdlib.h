#ifndef _STDLIB_H
#define _STDLIB_H

#include <types.h>

BYTE
atoi(char *s);

WORD
atol(char *s);

char *
itoa(BYTE n,
	 char *s);

char *
ltoa(WORD n,
	 char *s);

UBYTE
abs(BYTE num);

WORD
labs(WORD num);

#endif /* _STDLIB_H */

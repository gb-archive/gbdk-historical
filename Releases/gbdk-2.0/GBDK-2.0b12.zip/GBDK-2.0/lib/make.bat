..\bin\lcc -Wa-l -c -o crt0.o crt0.s

..\bin\lcc -Wa-l -c -o asl.o asl.s
..\bin\lcc -Wa-l -c -o asr.o asr.s
..\bin\lcc -Wa-l -c -o lsr.o lsr.s

..\bin\lcc -Wa-l -c -o div.o div.s
..\bin\lcc -Wa-l -c -o mul.o mul.s

..\bin\lcc -Wa-l -c -o memcpy.o memcpy.s
..\bin\lcc -Wa-l -c -o lreg.o lreg.s

..\bin\lcc -Wa-l -c -o fp_long.o fp_long.s

..\bin\lcc -Wa-l -c -o cpy_data.o cpy_data.s
..\bin\lcc -Wa-l -c -o delay.o delay.s
..\bin\lcc -Wa-l -c -o get_bk_t.o get_bk_t.s
..\bin\lcc -Wa-l -c -o get_wi_t.o get_wi_t.s
..\bin\lcc -Wa-l -c -o get_xy_t.o get_xy_t.s
..\bin\lcc -Wa-l -c -o hiramcpy.o hiramcpy.s
..\bin\lcc -Wa-l -c -o init_tt.o init_tt.s
..\bin\lcc -Wa-l -c -o mv_spr.o mv_spr.s
..\bin\lcc -Wa-l -c -o pad.o pad.s
..\bin\lcc -Wa-l -c -o prop_spr.o prop_spr.s
..\bin\lcc -Wa-l -c -o scroll_b.o scroll_b.s
..\bin\lcc -Wa-l -c -o scroll_w.o scroll_w.s
..\bin\lcc -Wa-l -c -o set_bk_d.o set_bk_d.s
..\bin\lcc -Wa-l -c -o set_bk_t.o set_bk_t.s
..\bin\lcc -Wa-l -c -o serial.o serial.s
..\bin\lcc -Wa-l -c -o set_spr.o set_spr.s
..\bin\lcc -Wa-l -c -o set_sp_d.o set_sp_d.s
..\bin\lcc -Wa-l -c -o set_wi_d.o set_wi_d.s
..\bin\lcc -Wa-l -c -o set_wi_t.o set_wi_t.s
..\bin\lcc -Wa-l -c -o set_xy_t.o set_xy_t.s

..\bin\lcc -Wa-l -c -o input.o input.s
..\bin\lcc -Wa-l -c -o output.o output.s

..\bin\lcc -Wa-l -c -o drawing.o drawing.s

..\bin\lcc -Wa-l -c -o abs.o abs.c
..\bin\lcc -Wa-l -c -o atoi.o atoi.c
..\bin\lcc -Wa-l -c -o atol.o atol.c
..\bin\lcc -Wa-l -c -o digits.o digits.c
..\bin\lcc -Wa-l -c -o isalpha.o isalpha.c
..\bin\lcc -Wa-l -c -o isdigit.o isdigit.c
..\bin\lcc -Wa-l -c -o islower.o islower.c
..\bin\lcc -Wa-l -c -o isspace.o isspace.c
..\bin\lcc -Wa-l -c -o isupper.o isupper.c
..\bin\lcc -Wa-l -c -o itoa.o itoa.c
..\bin\lcc -Wa-l -c -o lasb.o lasb.c
..\bin\lcc -Wa-l -c -o ltoa.o ltoa.c
..\bin\lcc -Wa-l -c -o print.o print.c
..\bin\lcc -Wa-l -c -o printf.o printf.c
..\bin\lcc -Wa-l -c -o println.o println.c
..\bin\lcc -Wa-l -c -o printn.o printn.c
..\bin\lcc -Wa-l -c -o puts.o puts.c
..\bin\lcc -Wa-l -c -o scanf.o scanf.c
..\bin\lcc -Wa-l -c -o sprint.o sprint.c
..\bin\lcc -Wa-l -c -o sprintf.o sprintf.c
..\bin\lcc -Wa-l -c -o sprintln.o sprintln.c
..\bin\lcc -Wa-l -c -o sprintn.o sprintn.c
..\bin\lcc -Wa-l -c -o strcat.o strcat.c
..\bin\lcc -Wa-l -c -o strcmp.o strcmp.c
..\bin\lcc -Wa-l -c -o strcpy.o strcpy.c
..\bin\lcc -Wa-l -c -o strlen.o strlen.c
..\bin\lcc -Wa-l -c -o strncat.o strncat.c
..\bin\lcc -Wa-l -c -o strncmp.o strncmp.c
..\bin\lcc -Wa-l -c -o strncpy.o strncpy.c
..\bin\lcc -Wa-l -c -o tolower.o tolower.c
..\bin\lcc -Wa-l -c -o toupper.o toupper.c

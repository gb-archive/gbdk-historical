	.include        "global.s"

	.globl  .set_xy_wtt

	.area   _CODE

_set_win_tiles::
	PUSH    BC

	LDA     HL,4(SP)        ; Skip return address and registers
	LD      D,(HL)          ; D = x
	INC     HL
	LD      E,(HL)          ; E = y
	LDA     HL,9(SP)
	LD      B,(HL)          ; BC = tilelist
	DEC     HL
	LD      C,(HL)
	DEC     HL
	LD      A,(HL-)         ; A = h
	LD      H,(HL)          ; H = w
	LD      L,A             ; L = h

	CALL    .set_xy_wtt

	POP     BC
	RET

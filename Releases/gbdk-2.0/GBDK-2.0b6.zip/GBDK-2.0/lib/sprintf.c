#include <stdio.h>
#include <stdarg.h>

BYTE sprintf(char *s, char *fmt, ...)
{
  va_list ap;
  BYTE nb = 0;
  UBYTE pos = 0;

  va_start(ap, fmt);
  for(; *fmt; fmt++)
    if(*fmt == '%') {
      switch(*++fmt) {
      case 'c':
		/* char */
		s[pos++] = va_arg(ap, char);
		break;
      case 'd':
		/* decimal int */
		pos += sprintn(s, va_arg(ap, BYTE), 10, SIGNED);
		break;
      case 'u':
		/* unsigned int */
		pos += sprintn(s, va_arg(ap, BYTE), 10, UNSIGNED);
		break;
      case 'o':
		/* octal int */
		pos += sprintn(s, va_arg(ap, BYTE), 8, UNSIGNED);
		break;
      case 'x':
		/* hexadecimal int */
		pos += sprintn(s, va_arg(ap, BYTE), 16, UNSIGNED);
		break;
      case 's':
		/* string */
		pos += sprint(s, va_arg(ap, char *));
		break;
      case 'l':
		/* long */
		switch(*++fmt) {
		case 'd':
		  /* decimal long */
		  pos += sprintln(s, va_arg(ap, WORD), 10, SIGNED);
		  break;
		case 'u':
		  /* unsigned long */
		  pos += sprintln(s, va_arg(ap, WORD), 10, UNSIGNED);
		  break;
		case 'o':
		  /* octal long */
		  pos += sprintln(s, va_arg(ap, WORD), 8, UNSIGNED);
		  break;
		case 'x':
		  /* hexadecimal long */
		  pos += sprintln(s, va_arg(ap, WORD), 16, UNSIGNED);
		  break;
		}
		break;
      case '%':
		/* % */
		s[pos++] = *fmt;
		break;
      default:
		s[pos] = 0;
		return -1;
      }
	  nb++;
	} else
	  s[pos++] = *fmt;
  va_end(ap);
  s[pos] = 0;

  return nb;
}

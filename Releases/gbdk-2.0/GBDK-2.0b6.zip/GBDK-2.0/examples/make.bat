..\bin\lcc -Wa-l -Wl-m -o space.gb space.s

..\bin\lcc -Wa-l -Wl-m -o galaxy.gb galaxy.c

..\bin\lcc -Wa-l -Wl-m -o rpn.gb rpn.c

..\bin\lcc -Wa-l -Wl-m -o sound.gb sound.c

..\bin\lcc -Wa-l -c -o banks.o banks.c
..\bin\lcc -Wa-l -Wf-BA0 -c -o bank_0.o bank_0.c
..\bin\lcc -Wa-l -Wf-BO1 -Wf-BA1 -c -o bank_1.o bank_1.c
..\bin\lcc -Wa-l -Wf-BO2 -Wf-BA2 -c -o bank_2.o bank_2.c
..\bin\lcc -Wa-l -Wf-BO3 -Wf-BA3 -c -o bank_3.o bank_3.c
..\bin\lcc -Wl-m -Wl-y4 -Wl-a1 -o banks.gb banks.o bank_0.o bank_1.o bank_2.o bank_3.o

..\bin\lcc -Wa-l -c -o ram_fn.o ram_fn.c
..\bin\lcc -Wl-m -Wl-g_inc_ram=0xD000 -Wl-g_inc_hiram=0xFFA0 -o ram_fn.gb ram_fn.o

..\bin\lcc -Wa-l -c -o irq.o irq.c
..\bin\lcc -Wl-m -Wl-g.irq_VBL=_vbl -Wl-g.irq_TIM=_tim -o irq.gb irq.o

/*
 */

#ifndef SDCCCONF_HEADER
#define SDCCCONF_HEADER


#undef SDCC_VERSION_HI
#undef SDCC_VERSION_LO
#undef SDCC_VERSION_P
#undef SDCC_VERSION_STR

#undef PREFIX
#undef DATADIR
#undef SRCDIR

#undef STANDARD_INCLUDE_DIR
#undef SDCC_INCLUDE_DIR
#undef SDCC_LIB_DIR
#undef STD_LIB
#undef STD_INT_LIB
#undef STD_LONG_LIB
#undef STD_FP_LIB
#undef HAVE_SYS_SOCKET_H
#undef HAVE_SYS_ISA_DEFS_H
#undef HAVE_ENDIAN_H
#endif

/* End of config.h */

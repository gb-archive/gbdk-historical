  virtual int nop(uint code);
  virtual int sleep(uint code);
  virtual int wdr(uint code);

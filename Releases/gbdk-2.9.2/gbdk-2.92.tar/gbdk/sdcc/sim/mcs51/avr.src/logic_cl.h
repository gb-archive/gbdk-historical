  virtual int ori_Rd_K(uint code);
  virtual int andi_Rd_K(uint code);
  virtual int and_Rd_Rr(uint code);
  virtual int eor_Rd_Rr(uint code);
  virtual int or_Rd_Rr(uint code);

#ifndef TYPES_INCLUDE
#define TYPES_INCLUDE

#include <asm/types.h>

#define	NULL     0

#define FALSE		0
#define TRUE		1

typedef void *       	POINTER;

#endif

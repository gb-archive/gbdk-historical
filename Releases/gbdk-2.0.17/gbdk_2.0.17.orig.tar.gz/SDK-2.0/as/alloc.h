/* alloc.h */
/* DECUS C */

extern	char	*alloc();
extern	char	*malloc();
extern	char	*calloc();
extern	char	*realloc();


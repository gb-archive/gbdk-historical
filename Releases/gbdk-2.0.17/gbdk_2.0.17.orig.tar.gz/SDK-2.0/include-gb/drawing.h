#define	SOLID  0
#define	XOR    1
#define	OR     2
#define	AND    3

#define	WHITE  0
#define	LTGREY 1
#define	DKGREY 2
#define	BLACK  3

void
plot(UBYTE x,
     UBYTE y,
     UBYTE color,
     UBYTE mode);

void
line(UBYTE x1,
     UBYTE y1,
     UBYTE x2,
     UBYTE y2,
     UBYTE color,
     UBYTE mode);

void
switch_data(UBYTE x,
	    UBYTE y,
	    unsigned char *src,
	    unsigned char *dst);

void
draw_image(unsigned char *data);

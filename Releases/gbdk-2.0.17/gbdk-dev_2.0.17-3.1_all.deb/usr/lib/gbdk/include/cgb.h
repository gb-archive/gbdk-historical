#ifndef _CGB_H
#define _CGB_H

void
set_bkg_palette(UBYTE first_palette,
		UBYTE nb_palettes,
		UWORD *rgb_data);

void
set_sprite_palette(UBYTE first_palette,
		   UBYTE nb_palettes,
		   UWORD *rgb_data);

#endif /* _CGB_H */

#ifndef __SYS_MEM_H
#include <gb.h>
#include <stdlib.h>

#define MALLOC_UNUSED	0
#define MALLOC_FREE	1
#define MALLOC_USED	2
#define MALLOC_MAGIC	123
#define MALLOC_NUMHUNKS	10
typedef struct smalloc_hunk	mmalloc_hunk;
typedef struct smalloc_hunk *	pmmalloc_hunk;

struct smalloc_hunk {
	UBYTE magic;
	pmmalloc_hunk	next;
	UWORD size;
	int status;
};

extern UBYTE malloc_heap_start;

extern pmmalloc_hunk malloc_first;

void malloc_gc(void);
void debug( char *routine, char *msg );
#endif	/* __SYS_MEM_H */

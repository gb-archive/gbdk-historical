#ifndef TYPES_INCLUDE
#define TYPES_INCLUDE

#include <asm/types.h>

#define	NULL     0

enum {
    FALSE,
    TRUE
};

typedef void *             POINTER;

#endif

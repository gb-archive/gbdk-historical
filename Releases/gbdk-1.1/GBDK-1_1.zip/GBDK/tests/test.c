#include <stdlib.h>
#include <stdio.h>
#include <graphics.h>
#include "fish.h"

void main()
{
  char s[16];
  int i, j, k;

  puts("A: text demo");
  puts("B: graphic demo");
  puts("START: picture");

  i = waitpad(J_A | J_B | J_START);
  waitpadup();

  if(i == J_A) {
    int i1, i2, i3;

    printf("Hello %s\n", "World");
    strcpy(s, "Hello World!");
    reverse(s);
    puts(s);

    for(i = 0; i <= 0x10; i++) {
      printn(i, 16);
      putchar(' ');
    }
    putchar(EOL);

    for(i = 0; i < 3; i++) {
      switch(i)
        {
        case 0:
          printn(0, 10);
          break;
        case 1:
          printn(1, 10);
		  break;
        case 2:
          printn(2, 10);
          break;
        default:
          print("Error");
		  break;
        }
      putchar(' ');
    }
    putchar(EOL);

    printf("Numbers: %c %d %o %x\n", 'A', 13, 13, 13);
    printf("Enter 3 nb:");
    i = scanf("%d %x %o", &i1, &i2, &i3);
    printf("Result: %d %d %d %d\n", i, i1, i2, i3);

    itoa(abs(-234), s);
    puts(s);
    itoa(-234, s);
    puts(s);
    itoa(atoi(s), s);
    puts(s);

    strcpy(s, "Hello");
    strcat(s, " World!");
    puts(s);

    printn(strlen(s), 10);
    putchar(EOL);

    printn(strcmp(s, "Hello Earth!"), 10);
    putchar(' ');
    printn(strcmp(s, "Hello World!"), 10);
    putchar(' ');
    printn(strcmp(s, "Hi World!"), 10);
    putchar(EOL);

    printf("Enter nb: ");
    puts(gets(s));
    printf("2 * ");
    print(s);
    printf(" = ");
    puts(itoa(atoi(s) * 2, s));

    printf("End of program");
  } else if(i == J_B) {
    int m = OR;
    int c = BLACK;

    i = 50;
    j = 50;
    k = 0;

    while(1) {
      if(i >= 0 && i <= 0x7F && j >= 0 && j <= 0x77)
        plot(i, j, c, m);
	  else {
		i = i < 0 ? 0 : i;
		j = j < 0 ? 0 : j;
		i = i > 0x7F ? 0x7F : i;
		j = j > 0x77 ? 0x77 : j;
	  }

      k = waitpad(J_UP | J_DOWN | J_LEFT | J_RIGHT | J_A | J_B | J_START);

      if(k & J_START) {
		break;
      }
      if(k & J_A) {
        m = ++m % 4;
		waitpadup();
      }
      if(k & J_B) {
        c = ++c % 4;
		waitpadup();
      }
	  if(k & J_UP)
        j--;
      if(k & J_DOWN)
        j++;
      if(k & J_LEFT)
        i--;
      if(k & J_RIGHT)
        i++;
      delay(500);
    }
  } else {
    draw_image(fish_data);
    waitpad(J_START);
  }
}

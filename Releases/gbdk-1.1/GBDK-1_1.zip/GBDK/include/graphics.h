#define	AND	0
#define	OR	1
#define	XOR	2
#define	SOLID	3

#define	WHITE	0
#define	LTGREY	1
#define	DKGREY	2
#define	BLACK	3

void	plot(int x, int y, int color, int mode);
void	draw_image(unsigned char *data);
/* image size = (0x80, 0x78)
 */

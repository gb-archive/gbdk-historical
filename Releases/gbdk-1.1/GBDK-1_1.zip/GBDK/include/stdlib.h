/* Joypad */

#define	J_START	0x80
#define	J_SELECT	0x40
#define	J_B		0x20
#define	J_A		0x10
#define	J_DOWN	0x08
#define	J_UP		0x04
#define	J_LEFT	0x02
#define	J_RIGHT	0x01

/* Modes */

#define	M_DRAWING	0x01
#define	M_TEXT	0x02

/* Sprite properties bits */

#define S_PALETTE	0x04
#define S_FLIPX	0x05
#define S_FLIPY	0x06
#define S_PRIORITY	0x07

/* ************************************************************ */

void	mode(int m);

/* ************************************************************ */

void	delay(int d);
void	pause(int p);

/* ************************************************************ */

int	joypad();
int	waitpad(int mask);
void	waitpadup();

/* ************************************************************ */

void	enable_interrupts();
void	disable_interrupts();

/* ************************************************************ */

void	display_on();
void	display_off();

/* ************************************************************ */

void	show_bkg();
void	hide_bkg();
void	set_bkg_data(int first_tile, int nb_tiles, unsigned char *data);
/* -128 <= first_tile <= 127
 * -128 <= first_tile+nb_tiles <= 127
 * nb_tiles >= 1
 */
void	set_bkg_tiles(int x, int y, int w, int h, unsigned char *tilelist);
/* 0 <= x <= 31
 * 0 <= y <= 31
 * 1 <= w <= 32-x
 * 1 <= h <= 32-y
 */
void	scroll_bkg(int x, int y);

/* ************************************************************ */

void	show_window();
void	hide_window();

/* ************************************************************ */

void	show_sprites();
void	hide_sprites();
void	sprites8x8();
void	sprites8x16();
void	set_sprite_data(int first_tile, int nb_tiles, unsigned char *data);
/* 0 <= first_tile <= 255
 * 0 <= first_tile+nb_tiles <= 255
 * nb_tiles >= 1
 */
void	set_sprite_tile(int nb, int tile);
/* 0 <= nb <= 39
 * 0 <= tile <= 255
 */
void	set_sprite_prop(int nb, int prop);
/* 0 <= nb <= 39
 */
void	move_sprite(int nb, int x, int y);
/* 0 <= nb <= 39
 * 0 <= x <= 255
 * 0 <= y <= 255
 */

#define	stdin	0
#define	stdout	1
#define	stderr	2
#define	NULL	0
#define	EOF	(-1)
#define	EOL	'\n'
#define	EOS	'\0'
#define	FILE	char

int	atoi(char *s);
int	abs(int num);
int	isalpha(char c);
int	isupper(char c);
int	islower(char c);
int	isdigit(char c);
int	isspace(char c);
int	toupper(char c);
int	tolower(char c);
int	index(char *s, char *t);
char	*itoa(int n, char *s);
void	printn(int number, int radix);
char	*reverse(char *s);
char	*strcat(char *s1, char *s2);
int	strcmp(char *s1, char *s2);
char	*strcpy(char *s1, char *s2);
int	strlen(char *s);
char	*strncat(char *s1, char *s2, int n);
int	strncmp(char *s1, char *s2, int n);
char	*strncpy(char *s1, char *s2, int n);
void	puts(char *str);
void	print(char *str);
void	printf(char *fmt, ...);
int	scanf(char *fmt, ...);

/* Assembly functions */
void	putchar(char c);
char	getchar();
char	*gets(char *s);

void    gotoxy(int x, int y);
int     posx();
int     posy();
void    setchar(char c);

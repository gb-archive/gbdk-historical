	.START	=	0x80
	.SELECT	=	0x40
	.B	=	0x20
	.A	=	0x10
	.DOWN	=	0x08
	.UP	=	0x04
	.LEFT	=	0x02
	.RIGHT	=	0x01

	.SCREENWIDTH	=	0xA0
	.SCREENHEIGHT	=	0x90
	.MINWNDPOSX	=	0x07
	.MINWNDPOSY	=	0x00
	.MAXWNDPOSX	=	0xA5	; Should be 0xA7, but it seems 0xA5 is the limit
	.MAXWNDPOSY	=	0x8F

	.VBL_IFLAG	=	0x01
	.LCD_IFLAG	=	0x02
	.TIM_IFLAG	=	0x04
	.SIO_IFLAG	=	0x08
	.JOY_IFLAG	=	0x10
 
	.JOYPAD		=	0x00	; Joystick: 1.1.P15.P14.P13.P12.P11.P10
	.SIODATA	=	0x01	; Serial IO data buffer
	.SIOCONT	=	0x02	; Serial IO control register
	.DIVREG		=	0x04	; Divider register (???)
	.TIMECNT	=	0x05	; Timer counter. Gen. int. when it overflows
	.TIMEMOD	=	0x06	; New value of TimeCount after it overflows
	.TIMEFRQ	=	0x07	; Timer frequency and start/stop switch
	.IFLAGS		=	0x0F	; Interrupt flags: 0.0.0.JST.SIO.TIM.LCD.VBL
	.ISWITCH	=	0xFF	; Switches to enable/disable interrupts
	.LCDCONT	=	0x40	; LCD control register
	.LCDSTAT	=	0x41	; LCD status register
	.SCROLLY	=	0x42	; Starting Y position of the background
	.SCROLLX	=	0x43	; Starting X position of the background
	.CURLINE	=	0x44	; Current screen line being scanned
	.CMPLINE	=	0x45	; Gen. int. when scan reaches this line
	.DMA		=	0x46	; DMA transfer
	.BGRDPAL	=	0x47	; Background palette
	.SPR0PAL	=	0x48	; Sprite palette #0
	.SPR1PAL	=	0x49	; Sprite palette #1
	.WNDPOSY	=	0x4A	; Window Y position
	.WNDPOSX	=	0x4B	; Window X position

	.G_MODE		=	0x01
	.T_MODE		=	0x02

	.MODE_TABLE	=	0x01E0

	.globl	.OAM
	.globl	.mode

	.globl	.set_mode
	.globl	.padup
	.globl	.jpad
	.globl	.wait_pad
	.globl	.wait_vbl
	.globl	.delay_ns
	.globl	.delay_ms
	.globl	.white
	.globl	.black
	.globl	.std_pal
	.globl	.init_tiles
	.globl	.mv_tiles
	.globl	.init_btt
	.globl	.set_btt
	.globl	.set_xy_btt
	.globl	.get_xy_btt
	.globl	.init_wtt
	.globl	.set_wtt
	.globl	.set_xy_wtt
	.globl	.get_xy_wtt
	.globl	.mv_sprite
	.globl	.set_sprite
	.globl	.prop_sprite
	.globl	.refresh_OAM

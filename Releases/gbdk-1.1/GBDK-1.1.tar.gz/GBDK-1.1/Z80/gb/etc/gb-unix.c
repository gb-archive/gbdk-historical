/* Unix */

#ifndef GBDK_PATH
#define GBDK_PATH "/usr/local/GBDK"
#endif

#include <string.h>

char *cpp[] = { GBDK_PATH"/bin/cpp",
	"-D__STDC__=1", "-DZ80", "-Dgb", "$1", "$2", "$3", 0 };
char *include[] = { "-I"GBDK_PATH"/include",
	0 };
char *com[] = { GBDK_PATH"/bin/rcc", "-target=gb-Z80",
	"$1", "$2", "$3", 0 };
char *as[] = { GBDK_PATH"/bin/asGB", "-o", "-n", "$3", "$1", "$2", 0 };
char *ld[] = { GBDK_PATH"/bin/linkGB", "-o", "$3",
	"-z", "-b_CODE=0x200", "-b_BSS=0xC000", "$1",
	GBDK_PATH"/lib/crt0.o",
	"$2", 0 };

int option(arg) char *arg; {
	return 0;
}

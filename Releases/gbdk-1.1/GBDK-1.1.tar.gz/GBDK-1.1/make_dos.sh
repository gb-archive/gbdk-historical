#! /bin/csh -v

setenv GBDK c:\\\\\\\\GBDK
setenv DOS $HOME/GBDK-dos

setenv ROOT $PWD
setenv LCC_DIR $ROOT/lcc
setenv Z80_DIR $ROOT/Z80/gb
setenv ASM_DIR $ROOT/as
setenv LNK_DIR $ROOT/link

setenv BLD_DIR /tmp/dos

mkdir -p $DOS/bin
mkdir -p $DOS/include
mkdir -p $DOS/lib
mkdir -p $DOS/doc
mkdir -p $DOS/examples
mkdir -p $DOS/tests
cp -f $ROOT/include/* $DOS/include
cp -f $ROOT/lib/* $DOS/lib
cp -f $ROOT/doc/* $DOS/doc
cp -f $ROOT/examples/* $DOS/examples
cp -f $ROOT/tests/* $DOS/tests
nroff -man $LCC_DIR/doc/lcc.1 > $DOS/doc/lcc.doc
foreach i ($DOS/doc/* $DOS/include/* $DOS/lib/* $DOS/examples/* $DOS/tests/*)
	unix2dos $i $i
end

rm -rf $BLD_DIR
mkdir -p $BLD_DIR

cd $LCC_DIR
make -f $Z80_DIR/Makefile CC=gcc CFLAGS=-DDOS LDFLAGS=-Wl,-s GBDK=$GBDK SRC=$Z80_DIR BUILDDIR=$BLD_DIR HOSTFILE=$Z80_DIR/etc/gb-dos.c lburg
make -f $Z80_DIR/Makefile CC=gcc-dos CFLAGS=-DDOS LDFLAGS=-Wl,-s GBDK=$GBDK SRC=$Z80_DIR BUILDDIR=$BLD_DIR HOSTFILE=$Z80_DIR/etc/gb-dos.c rcc cpp lcc-pc
mv $BLD_DIR/rcc.exe $DOS/bin
mv $BLD_DIR/cpp.exe $DOS/bin
mv $BLD_DIR/lcc-pc.exe $DOS/bin/lcc.exe

cd $BLD_DIR
make -f $ASM_DIR/Makefile CC=gcc-dos CFLAGS=-DDOS LDFLAGS=-Wl,-s SRC=$ASM_DIR
mv $BLD_DIR/asGB.exe $DOS/bin
make -f $LNK_DIR/Makefile CC=gcc-dos CFLAGS=-DDOS LDFLAGS=-Wl,-s SRC=$LNK_DIR
mv $BLD_DIR/linkGB.exe $DOS/bin

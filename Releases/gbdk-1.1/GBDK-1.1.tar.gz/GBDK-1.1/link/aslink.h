/* aslink.h */

/*
 * (C) Copyright 1989,1990
 * All Rights Reserved
 *
 * Alan R. Baldwin
 * 721 Berkeley St.
 * Kent, Ohio  44240
 */

#define	VERSION	"V01.50"

/* DECUS C void definition */
/* File/extension seperator */

#ifdef	decus
#define	VOID	char
#define	FSEPX	'.'
#endif

/* PDOS C void definition */
/* File/extension seperator */

#ifdef	PDOS
#define	VOID	char
#define	FSEPX	':'
#endif

/* Default void definition */
/* File/extension seperator */

#ifndef	VOID
#define	VOID	void
#define	FSEPX	'.'
#endif

/*
 * This file defines the format of the
 * relocatable binary file.
 */

#define	NCPS	16		/* characters per symbol */
#define	NDATA	16		/* actual data */
#define	NINPUT	128		/* Input buffer size */
#define	NHASH	64		/* Buckets in hash table */
#define	HMASK	077		/* Hash mask */
#define	NLPP	60		/* Lines per page */
#define	NTXT	16		/* T values */
#define	FILSPC	128		/* File spec length */

/*
 * Relocation types.
 */
#define	R_WORD	0000		/* 16 bit */
#define	R_BYTE	0001		/*  8 bit */

#define	R_AREA	0000		/* Base type */
#define	R_SYM	0002

#define	R_NORM	0000		/* PC adjust */
#define	R_PCR	0004

#define	R_BYT1	0000		/* Byte count for R_BYTE = 1 */
#define	R_BYT2	0010		/* Byte count for R_BYTE = 2 */

#define	R_SGND	0000		/* Signed value */
#define	R_USGN	0020		/* Unsigned value */

#define	R_NOPAG	0000		/* Page Mode */
#define	R_PAG0	0040		/* Page '0' */
#define	R_PAG	0100		/* Page 'nnn' */

/*
 * Global symbol types.
 */
#define	S_REF	1		/* referenced */
#define	S_DEF	2		/* defined */

/*
 * Area types
 */
#define	A_CON	000		/* concatenate */
#define	A_OVR	004		/* overlay */
#define	A_REL	000		/* relocatable */
#define	A_ABS	010		/* absolute */
#define	A_NOPAG	000		/* non-paged */
#define	A_PAG	020		/* paged */

/*
 * File types
 */
#define	F_STD	1		/* stdin */
#define	F_LNK	2		/* File.lnk */
#define	F_REL	3		/* File.o */

typedef unsigned int addr_t;

struct	head
{
	struct	head   *h_hp;	/* Header link */
	struct	lfile  *h_lfile;/* Associated file */
	int	h_narea;	/* # of areas */
	struct	areax **a_list;	/* Area list */
	int	h_nglob;	/* # of global symbols */
	struct	sym   **s_list;	/* Globle symbol list */
	char	m_id[NCPS];	/* Module name */
};

struct	area
{
	struct	area	*a_ap;	/* Area link */
	struct	areax	*a_axp;	/* Area extension link */
	addr_t	a_addr;		/* Beginning address of area */
	addr_t	a_size;		/* Total size of the area */
	char	a_type;		/* Area subtype */
	char	a_flag;		/* Flag byte */
	char	a_id[NCPS];	/* Name */
};

struct	areax
{
	struct	areax	*a_axp;	/* Area extension link */
	struct	area	*a_bap;	/* Base area link */
	struct	head	*a_bhp;	/* Base header link */
	addr_t	a_addr;		/* Beginning address of section */
	addr_t	a_size;		/* Size of the area in section */
};

struct	sym
{
	struct	sym	*s_sp;	/* Symbol link */
	struct	areax	*s_axp;	/* Symbol area link */
	char	s_type;		/* Symbol subtype */
	char	s_flag;		/* Flag byte */
	addr_t	s_addr;		/* Address */
	char	s_id[NCPS];	/* Name */
};

struct	lfile
{
	struct	lfile	*f_flp;	/* lfile link */
	int	f_type;		/* File type */
	char	*f_idp;		/* Pointer to file spec */
};

struct	base
{
	struct	base  *b_base;	/* Base link */
	char	      *b_strp;	/* String pointer */
};

struct	globl
{
	struct	globl *g_globl;	/* Global link */
	char	      *g_strp;	/* String pointer */
};

struct	sdp
{
	struct	area  *s_area;	/* Paged Area link */
	struct	areax *s_areax;	/* Paged Area Extension Link */
	addr_t	s_addr;		/* Page address offset */
};

struct	rerr
{
	int	aindex;		/* Linking area */
	int	mode;		/* Relocation mode */
	addr_t	rtbase;		/* Base address in section */
	int	rindex;		/* Area/Symbol reloaction index */
	addr_t	rval;		/* Area/Symbol offset value */
};

/* Variable definitions */

extern		char	*_abs_;
extern		char	*dext;
extern		char	*ip;
extern		char	ib[NINPUT];
extern		char	ctype[];

extern		char	ccase[];

#define	SPACE	0000
#define ETC	0000
#define	LETTER	0001
#define	DIGIT	0002
#define	BINOP	0004
#define	RAD2	0010
#define	RAD8	0020
#define	RAD10	0040
#define	RAD16	0100
#define	ILL	0200

#define	DGT2	DIGIT|RAD16|RAD10|RAD8|RAD2
#define	DGT8	DIGIT|RAD16|RAD10|RAD8
#define	DGT10	DIGIT|RAD16|RAD10
#define	LTR16	LETTER|RAD16

extern	struct	lfile	*startp;
extern	struct	lfile	*linkp;
extern	struct	lfile	*lfp;
extern	struct	lfile	*filep;
extern	struct	lfile	*cfp;
extern	struct	head	*headp;
extern	struct	head	*hp;
extern	struct	area	*areap;
extern	struct	area	*ap;
extern	struct	areax	*axp;
extern	struct	sym	*symhash[NHASH];
extern	struct	base	*basep;
extern	struct	base	*bsp;
extern	struct	globl	*globlp;
extern	struct	globl	*gsp;
extern	struct	sdp	sdp;
extern	struct	rerr	rerr;

extern		char	*ofname;
extern		FILE	*sfp;
extern		FILE	*ofp;
extern		FILE	*mfp;
extern		int	inpfil;
extern		int	cfile;
extern		int	oflag;
extern		int	sflag;
extern		int	mflag;
extern		int	vflag;
extern		int	xflag;
extern		int	radix;
extern		int	hilo;
extern		int casesensitive;
extern		int	pass;
extern		int	line;
extern		int	page;
extern		int	lop;
extern		int	rtcnt;
extern		addr_t	rtval[];
extern		int	rtflg[];

/* Program function definitions */

/* lkmain.c */
extern	VOID		addfile(char *p);
extern	FILE *		afile(char *fn, char *ft, int wf, int bf);
extern	VOID		bassav();
extern	VOID		gblsav();
extern	VOID		link();
extern	VOID		main(int argc, char *argv[]);
extern	VOID		map();
extern	VOID		setbas();
extern	VOID		setgbl();
extern	VOID		usage();

/* lklex.c */
extern	char		endline();
extern	char		get();
extern	VOID		getid(char *id, register int c);
extern	int		getmap(register int d);
extern	char		getnb();
extern	char *	fgetstring(char *s, int n, FILE *stream);
extern	int 		getline();
extern	int		more();
extern	VOID		skip(register int c);
extern	VOID		unget(register int c);

/* lkarea.c */
extern	VOID		lkparea(char *id);
extern	VOID		lnkarea();
extern	VOID		lnksect(register struct area *tap);
extern	VOID		newarea();

/* lkhead.c */
extern	VOID		module();
extern	VOID		newhead();

/* lksym.c */
extern	int		hash(register char *p);
extern	struct	sym *	lkpsym(char *id, int f);
extern	VOID *		new(unsigned int n);
extern	struct	sym *	newsym();
extern	VOID		symdef(FILE *fp);
extern	int		symeq(register char *p1, register char *p2);
extern	VOID		syminit();
extern	VOID		symmod(FILE *fp, struct sym *tsp);
extern	addr_t		symval(register struct sym *tsp);

/* lkeval.c */
extern	int		digit(register int c, register int r);
extern	addr_t		eval();
extern	addr_t		expr(int n);
extern	int		oprio(register int c);
extern	addr_t		term();

/* lklist.c */
extern	VOID		lstarea(struct area *rp);
extern	VOID		newpag(FILE *fp);
extern	VOID		slew(FILE *fp);

/* lkrloc.c */
extern	addr_t		add_b1(register addr_t v, register int i);
extern	addr_t		add_b2(addr_t v, int i);
extern	addr_t		add_w(register addr_t v, register int i);
extern	addr_t		evword();
extern	VOID		rele();
extern	VOID		reloc(char c);
extern	VOID		relt();
extern	VOID		relr();
extern	VOID		relp();
extern	VOID		relerr(char *str);
extern	char *		errmsg[];
extern	VOID		errdmp(FILE *fptr, char *str);
extern	VOID		relerp(char *str);
extern	VOID		erpdmp(FILE *fptr, char *str);
extern	VOID		prntval(FILE *fptr, addr_t v);

/* lks19.c */
extern	VOID		s19(int i);

/* lkihx.c */
extern	VOID		ihx(int i);

/* lkgb.c */
extern	VOID		gb(int i);


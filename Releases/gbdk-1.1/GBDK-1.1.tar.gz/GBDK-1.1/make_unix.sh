#! /bin/csh -v

setenv GBDK $HOME/GBDK

setenv ROOT $PWD
setenv LCC_DIR $ROOT/lcc
setenv Z80_DIR $ROOT/Z80/gb
setenv ASM_DIR $ROOT/as
setenv LNK_DIR $ROOT/link

setenv BLD_DIR /tmp/unix

mkdir -p $GBDK/bin
mkdir -p $GBDK/include
mkdir -p $GBDK/lib
mkdir -p $GBDK/doc
mkdir -p $GBDK/man/man1
mkdir -p $GBDK/examples
mkdir -p $GBDK/tests
cp -f $ROOT/include/* $GBDK/include
cp -f $ROOT/lib/* $GBDK/lib
cp -f $ROOT/doc/* $GBDK/doc
cp -f $LCC_DIR/doc/lcc.1 $GBDK/man/man1
cp -f $ROOT/examples/* $GBDK/examples
cp -f $ROOT/tests/* $GBDK/tests

rm -rf $BLD_DIR
mkdir -p $BLD_DIR

cd $LCC_DIR
make -f $Z80_DIR/Makefile CC=gcc CFLAGS=-DUNIX LDFLAGS=-Wl,-s GBDK=$GBDK SRC=$Z80_DIR BUILDDIR=$BLD_DIR HOSTFILE=$Z80_DIR/etc/gb-unix.c rcc cpp lcc
mv $BLD_DIR/rcc $GBDK/bin
mv $BLD_DIR/cpp $GBDK/bin
mv $BLD_DIR/lcc $GBDK/bin

cd $BLD_DIR
make -f $ASM_DIR/Makefile CC=gcc CFLAGS=-DUNIX LDFLAGS=-Wl,-s SRC=$ASM_DIR
mv $BLD_DIR/asGB $GBDK/bin
make -f $LNK_DIR/Makefile CC=gcc CFLAGS=-DUNIX LDFLAGS=-Wl,-s SRC=$LNK_DIR
mv $BLD_DIR/linkGB $GBDK/bin
